<script setup>
import Rollingrecs from './components/Rollingrecs.vue'
import Signup from "@/components/Signup.vue";
</script>

<template>
  <header>


  </header>

  <main>
    <Rollingrecs />
  </main>
</template>

<style scoped>
header {
  line-height: 1.5;
  text-align: center;
}

.logo {
  display: block;
  margin: 0 auto 2rem;
}

@media (min-width: 1024px) {
  header {
    display: flex;
    flex-direction: column;
    place-items: center;
  }

  .logo {
    margin: 0 0 1rem 0;
  }
}
</style>
