<script setup>
import { ref } from 'vue'
import albumimg from '../assets/albumimg.jpg'
import recsto from '../assets/recsto.jpg'
const count = ref(0)
</script>

<template>
  <header class="site-header">
    <div class="logo-section">
      <img :src="recsto" alt="recsto" class="recsto" width="125">
      <h1 class="site-title">Rolling Recs</h1>
    </div>


    <nav class="navbar">
      <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">Albums</a></li>
        <li><a href="#">Reviews</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
    </nav>
  </header>
  <div class="home">
    <h2>Hello Music Lovers!</h2>
    <p>Welcome to Rolling Recs.</p>
    <p>Click this button to give "fancy that" by pink pantheress an upvote!</p>

    <img :src="albumimg" alt="Album cover" class="album-image"   width="125"
         height="125" />
    <br>
    <button @click="count++">
      You Upvoted {{ count }} {{ count === 1 ? 'time' : 'times' }}
    </button>
  </div>
  <footer class="footer">
    Find us on FACEBOOK
    Find us on TWITTER
    Find us on INSTAGRAM
    Find us on WHATSAPP
  </footer>
</template>

<style scoped>
.footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #3a3a3a; /* 👈 grey background */
  color: white;
  padding: 1rem 2rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
  border-radius: 0 0 1rem 1rem;
}
.site-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #3a3a3a; /* 👈 grey background */
  color: white;
  padding: 1rem 2rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
  border-radius: 0 0 1rem 1rem;
}
.home {
  background: white;
  padding: 2rem;
  border-radius: 1rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  text-align: center;
  max-width: 400px;
  margin: 2rem auto;
  font-family: system-ui, sans-serif;
}

h2 {
  color: #333;
  margin-bottom: 0.5rem;
}

p {
  color: #666;
  margin-bottom: 1.5rem;
}

button {
  background-color: #3a3a3a;
  color: white;
  border: none;
  padding: 0.6rem 1.2rem;
  border-radius: 0.4rem;
  cursor: pointer;
  font-size: 1rem;
  transition: b
}
button:hover {
  background-color: #FF0000;
}
</style>