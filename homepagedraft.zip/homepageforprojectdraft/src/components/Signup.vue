<script setup lang="ts">

import { ref } from 'vue'
import recsto from '../assets/recsto.jpg'
const count = ref(0)

const name = ref('')
const message = ref('')
const submitted = ref(false)
function handleSubmit() {
  if (name.value && message.value) {
    submitted.value = true
  }
}
function resetForm() {
  name.value = ''
  message.value = ''
  submitted.value = false
}
</script>

<template>
  <header class="site-header">
    <div class="logo-section">
      <img :src="recsto" alt="recsto" class="recsto" width="125">
      <h1 class="site-title">Rolling Recs</h1>
    </div>


    <nav class="navbar">
      <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">Albums</a></li>
        <li><a href="#">Reviews</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
    </nav>
  </header>
  <div class="contact">
    <h2>Contact Us</h2>

    <div v-if="submitted">
      <p> Thank you, {{ name }}! Your message has been sent.</p>
      <button @click="resetForm">Send another</button>
    </div>

    <form v-else @submit.prevent="handleSubmit">
      <div class="form-group">
        <label for="name">Name:</label>
        <input id="name" v-model="name" type="text" required />
      </div>
      <div class="form-group">
        <label for="message">Message:</label>
        <textarea id="message" v-model="message" rows="3" required></textarea>
      </div>
      <button type="submit">Submit</button>
      Lab1 - Introduction to Vue.js
      10
    </form>
  </div>
</template>

<style scoped>

</style>