import { createApp } from 'vue'
import App from './App.vue'

// Optional: import global styles if you have any
import './assets/styles.css'

// Create and mount the Vue app
createApp(App).mount('#app')
